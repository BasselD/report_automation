# Provider Performance Hex Dashboard

This project turns the original HTML prototype into a Python Dash application. Python owns data loading, filtering, aggregation, normalization, thresholds, and Plotly. A vendored D3 build in `assets/d3.min.js` draws the hierarchical hex in the browser, so the container does not need a public CDN at runtime.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:8050`.

## Feed data into the app

The app accepts three routes:

1. **Bundled file:** replace `data/provider_metrics.csv` and restart the app.
2. **Configured file:** point `DATA_PATH` to a CSV, Parquet, or Excel file.

   ```bash
   DATA_PATH=/data/provider_metrics.parquet python app.py
   ```

3. **Browser upload:** use **Upload data** in the dashboard. CSV, Parquet, and Excel are supported. The uploaded data remains in that browser session and is not written to disk.

For Teradata or Redshift, replace the body of `load_data()` with a query or write the query output to a Parquet file and set `DATA_PATH`. For production-scale data, query and aggregate server-side instead of storing the full dataset in the browser.

## Required columns

The application validates these fields:

- Report Date
- Operational Market
- Managing Entity
- PCP Name
- PCP NPI
- Membership
- Member Months
- The 18 measures defined in `MEASURES` inside `app.py`

## Rollup rules

- PMPM, rates, risk, Stars, ADK, and EDK use member-month-weighted averages.
- `Surplus` is summed.
- Provider count is the distinct PCP NPI count.
- Normalization uses the 1st and 99th percentiles for the selected report date. Direction is reversed for measures where lower is favorable.

## Docker

```bash
docker build -t provider-hex-dash .
docker run --rm -p 8050:8050 provider-hex-dash
```

Mount a production file and point `DATA_PATH` to it:

```bash
docker run --rm -p 8050:8050 \
  -v /local/data:/data:ro \
  -e DATA_PATH=/data/provider_metrics.parquet \
  provider-hex-dash
```

## Styling

`assets/hex.js` draws the D3 hex. Measure names follow the three subsegments on each side, while category names follow the full outer edge. `assets/style.css` contains the page styling.
