window.dash_clientside = Object.assign({}, window.dash_clientside, {
  hex: {
    render: function (payload) {
      if (!payload || !payload.measures || typeof d3 === "undefined") {
        return window.dash_clientside.no_update;
      }

      const host = document.getElementById("hex-chart");
      if (!host) return window.dash_clientside.no_update;
      host.innerHTML = "";

      const width = Math.max(host.clientWidth || 620, 480);
      const height = Math.max(host.clientHeight || 600, 500);
      const cx = width / 2;
      const cy = height / 2 + 6;
      const R = Math.min(width * 0.35, height * 0.34, 205);
      const metricBand = 54;
      const groupBand = 45;
      const cos30 = Math.cos(Math.PI / 6);
      const color = {good: "#17845c", bad: "#c94d53", neutral: "#81949b", ref: "#d3a33d"};

      const svg = d3.select(host).append("svg")
        .attr("viewBox", `0 0 ${width} ${height}`)
        .attr("width", "100%").attr("height", "100%");
      const defs = svg.append("defs");
      const g = svg.append("g").attr("transform", `translate(${cx},${cy})`);

      function normal(groupIndex) { return groupIndex * 60 - 90; }
      function polar(radius, normalDeg, diffDeg) {
        const angle = (normalDeg + diffDeg) * Math.PI / 180;
        const diff = diffDeg * Math.PI / 180;
        const corrected = radius * cos30 / Math.cos(diff);
        return [corrected * Math.cos(angle), corrected * Math.sin(angle)];
      }
      function polygon(radius) {
        return payload.groups.map((_, i) => polar(radius, normal(i), -30).join(",")).join(" ");
      }
      function uprightLine(a, b) {
        let start = a, end = b;
        const angle = Math.atan2(end[1] - start[1], end[0] - start[0]) * 180 / Math.PI;
        if (angle > 90 || angle < -90) [start, end] = [end, start];
        return {start, end, length: Math.hypot(end[0] - start[0], end[1] - start[1])};
      }
      function addPath(id, radius, n, startDiff, endDiff) {
        const line = uprightLine(polar(radius, n, startDiff), polar(radius, n, endDiff));
        defs.append("path").attr("id", id)
          .attr("d", `M${line.start[0]},${line.start[1]} L${line.end[0]},${line.end[1]}`);
        return line.length;
      }

      for (let level = 1; level <= 5; level++) {
        g.append("polygon").attr("points", polygon(R * level / 5))
          .attr("class", level === 5 ? "hex-ring hex-ring-major" : "hex-ring");
      }

      payload.groups.forEach((_, i) => {
        const point = polar(R, normal(i), 0);
        g.append("line").attr("class", "hex-spoke")
          .attr("x1", 0).attr("y1", 0).attr("x2", point[0]).attr("y2", point[1]);
      });

      g.append("polygon").attr("points", polygon(R + metricBand))
        .attr("class", "hex-boundary");
      g.append("polygon").attr("points", polygon(R + metricBand + groupBand))
        .attr("class", "hex-boundary hex-boundary-outer");

      payload.measures.forEach((d, i) => {
        const groupIndex = Math.floor(i / 3);
        const subIndex = i % 3;
        const n = normal(groupIndex);
        const start = -30 + subIndex * 20;
        const end = start + 20;
        const p1 = polar(R * d.score, n, start);
        const p2 = polar(R * d.score, n, end);

        g.append("polygon")
          .datum(d)
          .attr("class", "hex-wedge")
          .attr("fill", color[d.status] || color.neutral)
          .attr("points", `0,0 ${p1.join(",")} ${p2.join(",")}`)
          .on("mousemove", function (event, item) {
            const tip = d3.select("#hex-tooltip");
            tip.style("opacity", 1)
              .style("left", `${event.clientX + 14}px`)
              .style("top", `${event.clientY + 12}px`)
              .html(`<strong>${item.group} · ${item.label}</strong><br>` +
                    `Selected: <b>${item.raw_display}</b><br>` +
                    `<span>${payload.reference_label}: ${item.reference_display}</span><br>` +
                    `<span>Normalized score: ${item.score.toFixed(2)} / 1.00</span>`);
          })
          .on("mouseleave", () => d3.select("#hex-tooltip").style("opacity", 0));

        if (Number.isFinite(d.reference_score)) {
          const r1 = polar(R * d.reference_score, n, start);
          const r2 = polar(R * d.reference_score, n, end);
          g.append("line").attr("class", "hex-reference")
            .attr("x1", r1[0]).attr("y1", r1[1]).attr("x2", r2[0]).attr("y2", r2[1]);
        }

        const metricPathId = `metric-path-${i}`;
        const metricLength = addPath(metricPathId, R + metricBand * 0.56, n, start + 1, end - 1);
        const text = g.append("text").attr("class", "hex-metric-label");
        text.append("textPath")
          .attr("href", `#${metricPathId}`).attr("startOffset", "50%")
          .attr("text-anchor", "middle")
          .attr("textLength", Math.max(35, metricLength - 5))
          .attr("lengthAdjust", "spacingAndGlyphs")
          .text(d.label);
      });

      payload.groups.forEach((groupName, i) => {
        const pathId = `group-path-${i}`;
        addPath(pathId, R + metricBand + groupBand * 0.55, normal(i), -27, 27);
        const text = g.append("text").attr("class", "hex-group-label");
        text.append("textPath").attr("href", `#${pathId}`)
          .attr("startOffset", "50%").attr("text-anchor", "middle").text(groupName);
      });

      g.append("text").attr("class", "hex-center-label").attr("y", -4).text("NORMALIZED");
      g.append("text").attr("class", "hex-center-label hex-center-sub").attr("y", 13)
        .text(payload.reference_mode === "compare" ? "VS COMPARISON" : "VS TARGET");

      return `${Date.now()}-${payload.measures.length}`;
    }
  }
});
