"""Membership Explorer: Dash app with native D3 hierarchy views.

Run:
    python app.py --csv data/sample_membership.csv
    python app.py --csv /path/to/membership.csv --mapping mapping.json --port 8050
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import plotly.graph_objects as go
from dash import Dash, Input, Output, State, ALL, ctx, dcc, html, dash_table, no_update

from data_model import MembershipData, METRIC_LABELS

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description='Interactive healthcare membership hierarchy')
parser.add_argument('--csv', type=Path, default=HERE / 'data' / 'sample_membership.csv')
parser.add_argument('--mapping', type=Path, default=None,
                    help='Optional JSON mapping from internal field keys to CSV headers')
parser.add_argument('--host', default='127.0.0.1')
parser.add_argument('--port', type=int, default=8050)
parser.add_argument('--debug', action='store_true')
args = parser.parse_args()
DATA = MembershipData(args.csv, args.mapping)

EXTERNAL_D3 = 'https://cdn.jsdelivr.net/npm/d3@7.9.0/dist/d3.min.js'
app = Dash(__name__, title='Membership Explorer',
           external_scripts=[EXTERNAL_D3], suppress_callback_exceptions=True)
server = app.server


def comma(n):
    return f'{n:,}'


def metric_fmt(val, name):
    if val is None:
        return 'N/A'
    if name == 'pdc':
        return f'{val:.1%}'
    if name in ('cost', 'total_cost'):
        return f'${val:,.0f}'
    if name in ('raf', 'risk'):
        return f'{val:.2f}'
    if name == 'gaps':
        return f'{val:.2f}'
    return f'{val:,.0f}'


def kpi(label, value, caption, accent='teal'):
    return html.Div(className=f'kpi kpi-{accent}', children=[
        html.Div(label, className='kpi-label'),
        html.Div(value, className='kpi-value'),
        html.Div(caption, className='kpi-caption'),
    ])


def panel_title(title, subtitle=''):
    return html.Div(className='panel-header', children=[
        html.Div([html.H3(title), html.P(subtitle)]),
    ])


def placeholder_figure(msg):
    fig = go.Figure()
    fig.add_annotation(text=msg, x=.5, y=.5, xref='paper', yref='paper',
                       showarrow=False, font=dict(size=14, color='#64748b'))
    return style_fig(fig)


def style_fig(fig, height=270):
    fig.update_layout(
        height=height, margin=dict(l=12, r=14, t=14, b=24),
        paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
        font=dict(family='Inter, Segoe UI, sans-serif', size=11, color='#526477'),
        showlegend=False,
        xaxis=dict(showgrid=False, zeroline=False, linecolor='#dbe5e9'),
        yaxis=dict(showgrid=False, zeroline=False, linecolor='#dbe5e9'),
    )
    return fig


def build_risk_figure(path):
    scores = DATA.risk_counts(path)
    if not DATA.metric_available['risk']:
        return placeholder_figure('No Risk Score column in this CSV')
    names = ['High', 'Moderate', 'Low']
    values = [scores[k] for k in names]
    colors = ['#e47b69', '#efbd69', '#34bca4']
    fig = go.Figure(go.Bar(x=values, y=names, orientation='h',
                           marker=dict(color=colors, cornerradius=5),
                           hovertemplate='%{y}: %{x:,} members<extra></extra>'))
    fig.update_yaxes(autorange='reversed', tickfont=dict(size=12))
    fig.update_xaxes(tickformat=',d')
    return style_fig(fig, 235)


def build_children_figure(path):
    children = DATA.child_summary(path, limit=8)
    if not children:
        return placeholder_figure('At the PCP level. Explore individual members.')
    children = list(reversed(children))
    labels = [c['name'][:27] + ('…' if len(c['name']) > 27 else '') for c in children]
    fig = go.Figure(go.Bar(x=[c['count'] for c in children], y=labels,
                           orientation='h', marker=dict(color='#568ea0', cornerradius=4),
                           customdata=[c['name'] for c in children],
                           hovertemplate='%{customdata}<br>%{x:,} members<extra></extra>'))
    fig.update_xaxes(tickformat=',d')
    fig.update_yaxes(tickfont=dict(size=11))
    return style_fig(fig, 255)


metric_options = [
    {'label': 'PDC adherence', 'value': 'pdc'},
    {'label': 'RAF', 'value': 'raf'},
    {'label': 'Risk score', 'value': 'risk'},
    {'label': 'Cost / member', 'value': 'cost'},
    {'label': 'Quality gaps', 'value': 'gaps'},
]

view_options = [
    {'label': '◉  Overview', 'value': 'sunburst'},
    {'label': '▥  Hierarchy', 'value': 'icicle'},
    {'label': '▦  Population', 'value': 'treemap'},
    {'label': '●  Members', 'value': 'members'},
]

table_columns = [
    {'name': 'Member ID', 'id': 'member_id'},
    {'name': 'Member Name', 'id': 'member_name'},
    {'name': 'Risk Tier', 'id': 'risk_tier'},
    {'name': 'RAF', 'id': 'raf'},
    {'name': 'PDC', 'id': 'pdc'},
    {'name': 'Risk Score', 'id': 'risk'},
    {'name': 'Total Cost', 'id': 'cost'},
    {'name': 'Quality Gaps', 'id': 'gaps'},
    {'name': 'ED Visits', 'id': 'ed_visits'},
]

app.layout = html.Div(className='app-shell', children=[
    dcc.Store(id='selection-store', data={'path': []}),
    dcc.Store(id='viz-data'),
    dcc.Download(id='csv-download'),
    html.Aside(className='sidebar', children=[
        html.Div(className='brand', children=[
            html.Div('M', className='brand-mark'),
            html.Div([html.Strong('Mosaic'), html.Span('POPULATION INTELLIGENCE')], className='brand-copy')
        ]),
        html.Div(className='sidebar-divider'),
        html.Div('WORKSPACE', className='sidebar-label'),
        html.Div('Membership Explorer', className='sidebar-active'),
        html.Div('DATA SOURCE', className='sidebar-label space-top'),
        html.Div(Path(DATA.source_path).name, className='file-chip', title=DATA.source_path),
        html.Div(className='sidebar-stats', children=[
            html.Div([html.Strong(comma(len(DATA.frame))), html.Span('member records')]),
            html.Div([html.Strong(str(DATA.stats(DATA.frame)['pcps'])), html.Span('unique PCP branches')]),
            html.Div([html.Strong(str(len(DATA.levels))), html.Span('hierarchy dimensions')]),
        ]),
        html.Div('JUMP TO PCP', className='sidebar-label space-top'),
        dcc.Dropdown(id='pcp-jump', options=DATA.jump_options(), placeholder='Search by PCP…',
                     className='pcp-dropdown', clearable=True),
        html.Div(className='sidebar-help', children=[
            html.Div('HOW TO EXPLORE', className='sidebar-label'),
            html.P('Click a segment to drill deeper. Use breadcrumbs to climb back up.'),
            html.P('Switch views without losing your place.'),
            html.P('At PCP level, the member detail becomes the focus.'),
        ]),
        html.Div('Prototype only · Fictional demo data', className='sidebar-foot'),
    ]),
    html.Main(className='main-content', children=[
        html.Div(className='topline', children=[
            html.Div([
                html.Div('ANALYTICS  /  MEMBERSHIP', className='eyebrow'),
                html.H1('Population Explorer'),
                html.P('Explore every level. Stay focused on what matters.', className='subtitle'),
            ]),
            html.Div(className='top-actions', children=[
                html.Button('↺  Reset view', id='reset-btn', n_clicks=0, className='button button-ghost'),
                html.Button('↓  Export selection', id='export-btn', n_clicks=0,
                            className='button button-primary'),
            ]),
        ]),
        html.Div(id='kpis', className='kpi-grid'),
        html.Div(className='breadcrumb-bar', children=[
            html.Div('CURRENT PATH', className='breadcrumb-label'),
            html.Div(id='breadcrumbs', className='breadcrumbs'),
            html.Div(id='scope-depth', className='depth-label'),
        ]),
        html.Div(className='viz-card', children=[
            html.Div(className='viz-controls', children=[
                html.Div([html.H2('Explore the hierarchy'),
                          html.P('One population, multiple perspectives', className='muted')]),
                dcc.RadioItems(id='view-control', options=view_options, value='icicle',
                               className='view-tabs', inline=True),
            ]),
            html.Div(className='viz-toolbar', children=[
                html.Div([html.Span('COLOR BY', className='field-label'),
                          dcc.Dropdown(id='metric-control', options=metric_options,
                                       value='pdc', clearable=False, className='metric-dropdown')],
                         className='control-row'),
                html.Span(id='view-description', className='chart-hint'),
            ]),
            html.Div(id='d3-hierarchy', className='d3-stage'),
            html.Div(id='d3-render-state', className='d3-error'),
            html.Div(className='viz-footer', children=[
                html.Div([html.Span(className='legend-dot legend-good'), ' favorable',
                          html.Span(className='legend-dot legend-neutral'), ' neutral',
                          html.Span(className='legend-dot legend-bad'), ' attention'],
                         className='legend'),
                html.Span('Area = member count  ·  Color = selected metric', className='muted'),
            ]),
        ]),
        html.Div(className='insight-grid', children=[
            html.Div(className='chart-card', children=[
                panel_title('Risk distribution', 'Distribution within the current selection'),
                dcc.Graph(id='risk-chart', config={'displayModeBar': False}),
            ]),
            html.Div(className='chart-card', children=[
                panel_title('Largest groups', 'Immediate children of your selected branch'),
                dcc.Graph(id='children-chart', config={'displayModeBar': False}),
            ]),
        ]),
        html.Div(className='table-card', children=[
            html.Div(className='table-head', children=[
                html.Div([html.H2('Member detail'),
                          html.P(id='table-caption', className='muted')]),
                dcc.Input(id='member-search', placeholder='Search member name or ID…',
                          type='text', debounce=True, className='search-input'),
            ]),
            dash_table.DataTable(
                id='member-table', columns=table_columns, data=[],
                page_action='custom', page_current=0, page_size=15, page_count=1,
                sort_action='custom', sort_mode='single', sort_by=[],
                style_table={'overflowX': 'auto'},
                style_header={'backgroundColor': '#f0f5f7', 'color': '#4d6476',
                              'border': 'none', 'fontWeight': '700', 'fontSize': '11px',
                              'fontFamily': 'Inter, Segoe UI, sans-serif', 'padding': '13px'},
                style_cell={'backgroundColor': '#fff', 'border': 'none', 'borderBottom': '1px solid #edf0f3',
                            'fontFamily': 'Inter, Segoe UI, sans-serif', 'fontSize': '12px',
                            'padding': '13px', 'textAlign': 'left', 'color': '#2f485b',
                            'minWidth': '90px', 'maxWidth': '210px', 'overflow': 'hidden',
                            'textOverflow': 'ellipsis'},
                style_data_conditional=[
                    {'if': {'filter_query': '{risk_tier} = "High"', 'column_id': 'risk_tier'},
                     'color': '#c76053', 'fontWeight': '700'},
                    {'if': {'filter_query': '{risk_tier} = "Low"', 'column_id': 'risk_tier'},
                     'color': '#159b80', 'fontWeight': '700'},
                ],
                css=[{'selector': '.previous-next-container', 'rule': 'margin:12px;'}],
            ),
        ]),
        html.Div('DEMO DASHBOARD   /   Not approved for PHI or production use.', className='footer'),
    ]),
])


@app.callback(
    Output('breadcrumbs', 'children'), Output('scope-depth', 'children'),
    Output('kpis', 'children'), Output('viz-data', 'data'),
    Output('risk-chart', 'figure'), Output('children-chart', 'figure'),
    Output('view-description', 'children'),
    Input('selection-store', 'data'), Input('view-control', 'value'),
    Input('member-search', 'value'),
)
def render_scope(selection, view, search):
    path = DATA.validated_path((selection or {}).get('path', []))
    subset = DATA.scope(path)
    stats = DATA.stats(subset)
    crumbs = [html.Button('All Markets', id={'type': 'crumb', 'index': 0},
                          className='crumb', n_clicks=0)]
    for i, name in enumerate(path):
        crumbs.extend([html.Span('›', className='crumb-sep'),
                       html.Button(name, id={'type': 'crumb', 'index': i + 1},
                                   className='crumb crumb-selected' if i == len(path)-1 else 'crumb',
                                   n_clicks=0)])
    cards = [
        kpi('TOTAL MEMBERS', comma(stats['count']), 'members in selected scope'),
        kpi('PRIMARY CARE PROVIDERS', comma(stats['pcps']), 'unique PCP branches', 'blue'),
        kpi('AVERAGE RAF', metric_fmt(stats['raf'], 'raf'), 'risk adjustment factor', 'gold'),
        kpi('AVERAGE PDC', metric_fmt(stats['pdc'], 'pdc'), 'medication adherence', 'teal'),
        kpi('OPEN QUALITY GAPS',
            comma(stats['total_gaps']) if stats['total_gaps'] is not None else 'N/A',
            'sum of member gaps', 'coral'),
    ]
    tree = DATA.tree(path, max_extra_depth=3, max_children=36)
    dots = DATA.member_dots(path, search=search, limit=450) if view == 'members' else []
    payload = {'tree': tree, 'members': dots, 'path': path,
               'levels': [label for _, label in DATA.levels],
               'count': stats['count'], 'available': DATA.metric_available,
               'has_more_members': len(DATA.members(path, search)) > len(dots) if view == 'members' else False}
    descriptions = {
        'sunburst': 'Radial overview · Click a wedge to drill in',
        'icicle': 'Layered hierarchy · Click a rectangle to drill in',
        'treemap': 'Population distribution · Area represents member count',
        'members': 'Member dots · Grouped by risk tier · Hover for details',
    }
    return (crumbs, f'LEVEL {len(path)} / {len(DATA.levels)}', cards, payload,
            build_risk_figure(path), build_children_figure(path), descriptions.get(view, ''))


@app.callback(
    Output('selection-store', 'data'), Output('view-control', 'value'),
    Input('reset-btn', 'n_clicks'), Input('pcp-jump', 'value'),
    Input({'type': 'crumb', 'index': ALL}, 'n_clicks'),
    State('selection-store', 'data'), prevent_initial_call=True,
)
def navigation(reset_clicks, jump, clicks, selected):
    source = ctx.triggered_id
    if source == 'reset-btn':
        return {'path': []}, 'icicle'
    if source == 'pcp-jump' and jump:
        try:
            path = DATA.validated_path(json.loads(jump))
        except (ValueError, TypeError, json.JSONDecodeError):
            return no_update, no_update
        return {'path': path}, 'members'
    if isinstance(source, dict) and source.get('type') == 'crumb':
        # Pattern-matched breadcrumb children can mount with n_clicks=0.
        # Treat only an actual positive click as a navigation request.
        if not any(int(n or 0) > 0 for n in (clicks or [])):
            return no_update, no_update
        index = source.get('index', 0)
        path = DATA.validated_path((selected or {}).get('path', []))
        return {'path': path[:index]}, no_update
    return no_update, no_update


@app.callback(Output('member-table', 'page_current'),
              Input('selection-store', 'data'), Input('member-search', 'value'),
              prevent_initial_call=True)
def reset_table_page(_selection, _search):
    return 0


@app.callback(
    Output('member-table', 'data'), Output('member-table', 'page_count'),
    Output('table-caption', 'children'),
    Input('selection-store', 'data'), Input('member-search', 'value'),
    Input('member-table', 'page_current'), Input('member-table', 'page_size'),
    Input('member-table', 'sort_by'),
)
def member_table(selection, search, current_page, page_size, sort_by):
    path = DATA.validated_path((selection or {}).get('path', []))
    df = DATA.members(path, search=search)
    if sort_by:
        ordering = sort_by[0]
        column = ordering.get('column_id')
        if column in df.columns:
            df = df.sort_values(column, ascending=(ordering['direction'] == 'asc'),
                                kind='mergesort', na_position='last')
    total = len(df)
    page_size = max(1, int(page_size or 15))
    pages = max(1, math.ceil(total / page_size))
    page = max(0, min(int(current_page or 0), pages-1))
    df = df.iloc[page * page_size:(page + 1) * page_size].copy()
    rows = []
    for _, r in df.iterrows():
        rows.append({
            'member_id': r['member_id'], 'member_name': r['member_name'],
            'risk_tier': r['risk_tier'],
            'raf': None if math.isnan(r['raf']) else round(float(r['raf']), 2),
            'pdc': None if math.isnan(r['pdc']) else f"{r['pdc']:.0%}",
            'risk': None if math.isnan(r['risk']) else round(float(r['risk']), 2),
            'cost': None if math.isnan(r['cost']) else f"${r['cost']:,.0f}",
            'gaps': None if math.isnan(r['gaps']) else int(r['gaps']),
            'ed_visits': None if math.isnan(r['ed_visits']) else int(r['ed_visits']),
        })
    caption = f"{total:,} matching members. Server-side pagination, {page_size} rows per page."
    return rows, pages, caption


@app.callback(Output('csv-download', 'data'), Input('export-btn', 'n_clicks'),
              State('selection-store', 'data'), prevent_initial_call=True)
def download_scope(n_clicks, selected):
    path = DATA.validated_path((selected or {}).get('path', []))
    subset = DATA.scope(path)
    return dcc.send_data_frame(subset.to_csv, 'membership_selection.csv', index=False)


app.clientside_callback(
    """function(payload, view, metric) {
         if (!payload) return '';
         if (!window.membershipD3) return 'D3 view assets have not loaded.';
         return window.membershipD3.draw(payload, view, metric) || '';
       }""",
    Output('d3-render-state', 'children'),
    Input('viz-data', 'data'), Input('view-control', 'value'),
    Input('metric-control', 'value'),
)

if __name__ == '__main__':
    print(f'\nMembership Explorer: http://{args.host}:{args.port}')
    print(f'CSV: {DATA.source_path}, records: {len(DATA.frame):,}, hierarchy depth: {len(DATA.keys)}')
    print(f'D3 served from: {EXTERNAL_D3} (internet required in the browser)\n')
    app.run(host=args.host, port=args.port, debug=args.debug)
