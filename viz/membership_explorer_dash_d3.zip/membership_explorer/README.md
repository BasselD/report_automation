# Mosaic Membership Explorer

A Dash dashboard that integrates **four native D3.js visualizations** with Plotly KPI charts and a Python-paginated member table. Selection state is synchronized across views.

## Included files

```text
membership_explorer/
├── app.py                      Main Dash app and callbacks
├── data_model.py               CSV aliases, validation, data aggregation
├── generate_dummy.py           Reproducible fictional data generator
├── requirements.txt            Python dependencies
├── mapping.example.json        Example custom CSV column mapping
├── data/sample_membership.csv  1,728 synthetic member records
├── assets/styles.css           Interface styling
├── assets/membership_d3.js     Sunburst, icicle, treemap, risk-tier dots
└── tests/test_model.py         Data-integrity regression tests
```

## 1. Install and start

**macOS / Linux**

```bash
cd membership_explorer
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py --csv data/sample_membership.csv
```

**Windows PowerShell**

```powershell
cd membership_explorer
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py --csv data/sample_membership.csv
```

Open **http://127.0.0.1:8050**.

For another port: `python app.py --port 8060`.
For remote development: `python app.py --host 0.0.0.0 --port 8050` (only on networks you trust).

**D3 JavaScript is loaded from jsDelivr over the internet**. For environments without external CDN access, download D3 v7.9.0 from `https://cdn.jsdelivr.net/npm/d3@7.9.0/dist/d3.min.js`, place it in `assets/00_d3.min.js`, then remove the `external_scripts=[EXTERNAL_D3]` parameter from `Dash(...)` in `app.py`. External Google Fonts are optional and the CSS has fallbacks.

## 2. Load your own CSV

Each row is **one member assigned to one PCP**. The app reads the CSV once at launch. Use a column named `Member ID` if possible. Distinct organizational groups are identified by the entire hierarchy path, not by PCP name alone.

```bash
python app.py --csv "/path/to/my_membership.csv"
```

Recognized hierarchy columns, in order:

1. `Operational Market` (required)
2. `Operational` (optional)
3. `Submarket` (optional)
4. `Managing Entity` (optional)
5. `Reporting Pod` (optional)
6. `Pod Name` (optional)
7. `PCP` or `PCP Name` (required)
8. `Member Name` or `Member ID` (at least one required)

The sample CSV has all seven aggregate hierarchy dimensions, plus individual member names. Missing optional dimensions are skipped. Spaces, underscores and case differences in recognized column headers are tolerated.

Supported optional **numeric** measures (shown as N/A if missing): `RAF`, `PDC`, `Risk Score`, `Total Cost`, `Quality Gaps`, `ED Visits`. PDC accepts decimal fractions (0–1) or percentages (0–100). Risk-tier thresholds in the demo are **High ≥ 0.75**, **Moderate ≥ 0.40**, and Low below 0.40. Change these in `data_model.py` to match your analytic definitions. Colors assume higher PDC is favorable, lower risk/cost/gaps is favorable, and treat RAF as neutral sequential shading (not a performance grade).

To map arbitrary column headers, make your own JSON from `mapping.example.json` and change values to match your CSV. Keep only mappings that apply:

```json
{
  "operational_market": "OPS_MKT_DESC",
  "submarket": "MKT_AREA",
  "managing_entity": "MANAGING_ENTITY_DESC",
  "reporting_pod": "REPORTING_POD",
  "pod_name": "POD_NM",
  "pcp": "PCP_DISPLAY_NAME",
  "member_name": "MEMBER_DISPLAY_NAME",
  "member_id": "MEMBER_UNIQUE_ID",
  "pdc": "ADHERENCE_PDC"
}
```

Run it with:

```bash
python app.py --csv "/path/to/your.csv" --mapping mapping.json
```

## 3. Explore and interact

- **Hierarchy / icicle**: Primary view. Width represents member count. Click a rectangle to reroot.
- **Overview / sunburst**: Circular summary, three levels at a time. Click sectors to zoom.
- **Population / treemap**: Shows relative membership distribution by rectangular area.
- **Members**: Up to 450 member dots grouped by risk tier. Dot radius is based on cost when available. Clicking a dot filters the detail table to that member. A Python-paginated table below covers the full current selection.
- **Breadcrumbs and PCP search**: Navigate without losing the selected path when you switch views.
- **Color by**: PDC, RAF, risk, cost, quality gaps. Missing measures are neutral. Colors use within-visible-group ranges for most measures, so compare colors only within the current view, not across unrelated scopes.
- **Export selection**: Outputs rows from the current hierarchy scope, without applying the member text search filter.

Every D3 view intentionally displays **only the next 3 levels below the selected node**, not the entire member tree. Clicking deeper progressively reveals the next levels. Each PCP leads to the member view.

## 4. Regenerate demo data / run tests

```bash
python generate_dummy.py --output data/sample_membership.csv --members-per-pcp 9
python -m unittest discover -s tests -v
```

## Architecture and scaling notes

- Backend: `data_model.py` loads and aggregates CSV in pandas. Dash serves branch summaries to D3 and Plotly.
- Frontend: `assets/membership_d3.js` renders SVG directly and writes selection into Dash's `selection-store` using `dash_clientside.set_props`.
- Member table: data search/sort/page operations are processed on the server; only one page is transferred.
- Member dots: hard-capped to 450 matching rows. For truly large populations, do not send all members to D3; aggregate into hex bins or a server-calculated risk histogram first.
- Hierarchy: each depth is capped at 36 visible child groups. Extra groups are rolled into a non-clickable `other groups` summary; drill into the relevant parent, or adjust `max_children` in `app.py` for your needs. This is a first-stage visualization cap, not a data filter.
- **Important for large files**: This prototype loads the whole CSV in server memory and computes group aggregations on request. For millions of members use DuckDB/Redshift/Teradata with preaggregated hierarchies, server-side caching, query-based paging, and row-level security.

## Security

**Use synthetic data only for evaluation.** Do not run this example on protected health information (PHI) in an unapproved environment. It has no authentication, audit logging, permissions, session isolation or row-level security. It may include member names in tooltips, CSV exports, browser state and visual data payloads. Production deployment requires proper access controls, PHI governance, secure network delivery, and a vetted locally hosted D3 bundle.
