"""Create reproducible fictional test members. No real member information."""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

MARKETS = {
    'Tennessee': ['Chattanooga', 'Nashville'],
    'Texas': ['Houston', 'Dallas'],
    'Arizona': ['Phoenix', 'Tucson'],
}
FIRST = ['Avery', 'Morgan', 'Jordan', 'Riley', 'Parker', 'Quinn', 'Taylor', 'Rowan',
         'Harper', 'Kai', 'Alex', 'Drew', 'Casey', 'Blake', 'Emerson', 'Reese']
LAST = ['Rivera', 'Kim', 'Hughes', 'Patel', 'Morales', 'Carter', 'Shah', 'Brooks',
        'Turner', 'Bennett', 'Wright', 'Santos', 'Foster', 'Chen', 'Cooper', 'Ali']


def make_dummy(path, seed=42, members_per_pcp=9):
    rng = np.random.default_rng(seed)
    rows = []
    index = 0
    for market, submarkets in MARKETS.items():
        for op_i, operation in enumerate(['Operations North', 'Operations South']):
            for submarket in submarkets:
                for me_i in range(2):
                    entity = f'{market[:2].upper()} Managed Group {chr(65 + me_i)}'
                    for reporting_i in range(2):
                        reporting_pod = f'Reporting Pod {reporting_i + 1}'
                        for pod_i in range(2):
                            pod = f'{submarket} Pod {pod_i + 1}'
                            for pcp_i in range(2):
                                pcp = f'Dr. {LAST[(index // members_per_pcp) % len(LAST)]} {pcp_i + 1}'
                                for _ in range(members_per_pcp):
                                    index += 1
                                    risk = float(rng.beta(2.2, 3.6))
                                    pdc = float(np.clip(rng.normal(.87 - .19 * risk, .13), .20, 1.00))
                                    cost = float(np.round(rng.lognormal(8.4 + .8 * risk, .65), 2))
                                    raf = float(np.round(np.clip(rng.normal(.85 + .95 * risk, .25), .3, 3.5), 2))
                                    gaps = int(rng.poisson(.45 + risk * 2.1))
                                    rows.append({
                                        'Operational Market': market,
                                        'Operational': operation,
                                        'Submarket': submarket,
                                        'Managing Entity': entity,
                                        'Reporting Pod': reporting_pod,
                                        'Pod Name': pod,
                                        'PCP': pcp,
                                        'Member Name': f'{FIRST[int(rng.integers(len(FIRST)))]} {LAST[int(rng.integers(len(LAST)))]}',
                                        'Member ID': f'DEMO-{index:06d}',
                                        'RAF': raf, 'PDC': round(pdc, 3), 'Risk Score': round(risk, 3),
                                        'Total Cost': cost, 'Quality Gaps': gaps,
                                        'ED Visits': int(rng.poisson(.12 + .55 * risk)),
                                    })
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False)
    return path, len(rows)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='data/sample_membership.csv')
    parser.add_argument('--members-per-pcp', type=int, default=9)
    args = parser.parse_args()
    target, count = make_dummy(args.output, members_per_pcp=args.members_per_pcp)
    print(f'Created {target} with {count:,} fictional members.')
