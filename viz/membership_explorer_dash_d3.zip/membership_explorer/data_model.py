"""CSV schema recognition, hierarchical aggregation and scoped member querying.
One source row represents one member assigned to one PCP.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

LEVELS = [
    ('operational_market', 'Operational Market'),
    ('operational', 'Operational'),
    ('submarket', 'Submarket'),
    ('managing_entity', 'Managing Entity'),
    ('reporting_pod', 'Reporting Pod'),
    ('pod_name', 'Pod Name'),
    ('pcp', 'PCP'),
]
ALIASES = {
    'operational_market': ['Operational Market', 'Operational_Market', 'Market', 'Ops Market'],
    'operational': ['Operational', 'Operational Region', 'Operational Division', 'Operations'],
    'submarket': ['Submarket', 'Sub Market', 'Operational Submarket', 'Sub-Market'],
    'managing_entity': ['Managing Entity', 'Managing_Entity', 'Managing Organization', 'ME'],
    'reporting_pod': ['Reporting Pod', 'Reporting_Pod', 'Reporting Pod Name'],
    'pod_name': ['Pod Name', 'Pod_Name', 'Pod'],
    'pcp': ['PCP', 'PCP Name', 'Primary Care Provider', 'Provider Name'],
    'member_name': ['Member Name', 'Member', 'Patient Name'],
    'member_id': ['Member ID', 'Member_ID', 'Patient ID', 'Subscriber ID'],
    'raf': ['RAF', 'RAF Score', 'Risk Adjustment Factor'],
    'pdc': ['PDC', 'PDC Rate', 'Medication Adherence', 'Adherence PDC'],
    'risk': ['Risk Score', 'Risk_Score', 'Predictive Risk', 'Clinical Risk Score'],
    'cost': ['Total Cost', 'Total Cost USD', 'Cost', 'Total Paid', 'Spend'],
    'gaps': ['Quality Gaps', 'Open Gaps', 'Care Gaps', 'Gap Count'],
    'ed_visits': ['ED Visits', 'Emergency Visits', 'ED Utilization'],
}
METRIC_LABELS = {
    'pdc': 'Average PDC',
    'raf': 'Average RAF',
    'risk': 'Average risk score',
    'cost': 'Cost per member',
    'gaps': 'Open gaps per member',
}


def normal(s):
    return re.sub(r'[^a-z0-9]+', '', str(s).strip().lower())


def resolve_columns(columns, mapping_path=None):
    custom = json.loads(Path(mapping_path).read_text(encoding='utf-8')) if mapping_path else {}
    available = {normal(c): c for c in columns}
    resolved = {}
    for key, names in ALIASES.items():
        desired = [custom[key]] if key in custom else names
        for candidate in desired:
            if normal(candidate) in available:
                resolved[key] = available[normal(candidate)]
                break
        if key in custom and key not in resolved:
            raise ValueError(f"Mapping for '{key}' points to absent CSV column '{custom[key]}'.")
    if 'pcp' not in resolved:
        raise ValueError("CSV must contain a PCP column (for example 'PCP' or 'PCP Name').")
    if 'operational_market' not in resolved:
        raise ValueError("CSV must contain 'Operational Market' (or 'Market').")
    return resolved


class MembershipData:
    def __init__(self, csv_path, mapping_path=None):
        path = Path(csv_path)
        if not path.exists():
            raise FileNotFoundError(f'CSV not found: {path.resolve()}')
        raw = pd.read_csv(path, dtype=str, low_memory=False, keep_default_na=False)
        if raw.empty:
            raise ValueError('The CSV is empty.')
        self.source_path = str(path)
        self.mapped = resolve_columns(raw.columns, mapping_path)
        self.levels = [(key, label) for key, label in LEVELS if key in self.mapped]
        if 'member_name' not in self.mapped and 'member_id' not in self.mapped:
            raise ValueError("Include at least 'Member Name' or 'Member ID' to identify members.")
        frame = pd.DataFrame(index=raw.index)
        for key, _ in self.levels:
            frame[key] = raw[self.mapped[key]].astype(str).str.strip().replace('', '(Unassigned)')
        frame['member_id'] = (raw[self.mapped['member_id']].astype(str).str.strip()
                              if 'member_id' in self.mapped else pd.Series('', index=raw.index))
        # Fallback is deterministic within this input file; real data should contain a stable member ID.
        missing_id = frame['member_id'].eq('')
        frame.loc[missing_id, 'member_id'] = ['ROW-' + str(i + 1).zfill(7) for i in frame.index[missing_id]]
        frame['member_name'] = (raw[self.mapped['member_name']].astype(str).str.strip()
                                if 'member_name' in self.mapped else frame['member_id'])
        frame['member_name'] = frame['member_name'].replace('', '(Unnamed member)')
        for k in ['raf', 'pdc', 'risk', 'cost', 'gaps', 'ed_visits']:
            if k in self.mapped:
                vals = raw[self.mapped[k]].str.replace(r'[$,%\s,]', '', regex=True)
                frame[k] = pd.to_numeric(vals, errors='coerce')
            else:
                frame[k] = np.nan
        # PDC is always represented internally as 0.0 ... 1.0.
        if frame['pdc'].dropna().gt(1).any():
            frame['pdc'] = frame['pdc'] / 100.0
        frame['risk_tier'] = np.select(
            [frame['risk'] >= .75, frame['risk'] >= .40, frame['risk'].notna()],
            ['High', 'Moderate', 'Low'], default='Unknown')
        self.frame = frame
        self.keys = [k for k, _ in self.levels]
        self.metric_available = {k: frame[k].notna().any() for k in METRIC_LABELS}

    def validated_path(self, path):
        """Validate prefix against actual hierarchy; truncate malformed paths."""
        path = path if isinstance(path, list) else []
        values = []
        candidate = self.frame
        for i, segment in enumerate(path[:len(self.keys)]):
            if not isinstance(segment, str):
                break
            child = candidate[candidate[self.keys[i]] == segment]
            if child.empty:
                break
            values.append(segment)
            candidate = child
        return values

    def scope(self, path):
        frame = self.frame
        for i, segment in enumerate(self.validated_path(path)):
            frame = frame[frame[self.keys[i]] == segment]
        return frame

    def stats(self, frame):
        def avg(key):
            v = frame[key].mean()
            return None if pd.isna(v) else round(float(v), 4)
        return {
            'count': int(len(frame)),
            'pcps': int(frame[self.keys].drop_duplicates().shape[0]),
            'raf': avg('raf'), 'pdc': avg('pdc'), 'risk': avg('risk'),
            'cost': avg('cost'), 'gaps': avg('gaps'),
            'total_cost': (None if frame['cost'].notna().sum() == 0
                           else round(float(frame['cost'].sum()), 2)),
            'total_gaps': (None if frame['gaps'].notna().sum() == 0
                           else int(frame['gaps'].sum())),
        }

    def tree(self, path, max_extra_depth=3, max_children=50):
        selected = self.validated_path(path)
        subset = self.scope(selected)
        start = len(selected)
        stop = min(len(self.keys), start + max_extra_depth)
        root = {'name': selected[-1] if selected else 'All markets',
                'level': self.levels[start-1][1] if selected else 'Portfolio',
                'path': selected, **self.stats(subset)}
        # Aggregating per depth avoids sending member records to the D3 hierarchy.
        def add_children(parent, df, depth):
            if depth >= stop or df.empty:
                return
            key, label = self.levels[depth]
            chunks = [(name, group) for name, group in df.groupby(key, sort=False)]
            chunks.sort(key=lambda t: len(t[1]), reverse=True)
            children = []
            for name, group in chunks[:max_children]:
                child = {'name': str(name), 'level': label,
                         'path': parent['path'] + [str(name)], **self.stats(group)}
                add_children(child, group, depth + 1)
                children.append(child)
            # UI marks the existence of suppressed branches without treating them as selectable nodes.
            if len(chunks) > max_children:
                omitted = pd.concat([chunk for _, chunk in chunks[max_children:]])
                children.append({'name': f'{len(chunks) - max_children} other groups',
                                 'level': label, 'path': parent['path'], 'non_clickable': True,
                                 **self.stats(omitted)})
            if children:
                parent['children'] = children
        add_children(root, subset, start)
        return root

    def members(self, path, search='', limit=None):
        df = self.scope(path)
        if search:
            phrase = str(search).strip()
            if phrase:
                df = df[df['member_name'].str.contains(phrase, case=False, regex=False, na=False) |
                        df['member_id'].str.contains(phrase, case=False, regex=False, na=False)]
        if limit is not None:
            df = df.head(limit)
        return df

    def member_dots(self, path, search='', limit=450):
        df = self.members(path, search, limit)
        cols = ['member_id', 'member_name', 'risk_tier', 'raf', 'pdc', 'cost', 'gaps', 'risk']
        items = df[cols].replace([np.inf, -np.inf], np.nan).astype(object)
        items = items.where(pd.notna(items), None)
        return items.to_dict('records')

    def jump_options(self, max_options=6000):
        # Full path disambiguates duplicate PCP names in distinct markets/pods.
        unique = self.frame[self.keys].drop_duplicates().head(max_options)
        options = []
        for row in unique.itertuples(index=False, name=None):
            path = list(row)
            options.append({'label': f'{path[-1]}  ·  {" / ".join(path[:-1])}',
                            'value': json.dumps(path)})
        return options

    def child_summary(self, path, limit=10):
        path = self.validated_path(path)
        if len(path) >= len(self.keys):
            return []
        sub = self.scope(path)
        key = self.keys[len(path)]
        return [{'name': str(name), 'count': int(n)} for name, n in
                sub.groupby(key).size().sort_values(ascending=False).head(limit).items()]

    def risk_counts(self, path):
        counts = self.scope(path)['risk_tier'].value_counts()
        return {name: int(counts.get(name, 0)) for name in ['High', 'Moderate', 'Low', 'Unknown']}
