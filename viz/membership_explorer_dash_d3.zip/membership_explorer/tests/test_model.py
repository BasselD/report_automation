import json
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from data_model import MembershipData, resolve_columns
from generate_dummy import make_dummy


class TestMembershipModel(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.csv, count = make_dummy(Path(cls.tmp.name) / 'demo.csv')
        cls.model = MembershipData(cls.csv)
        cls.count = count

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_csv_and_levels(self):
        self.assertEqual(len(self.model.keys), 7)
        self.assertEqual(len(self.model.frame), 1728)
        self.assertEqual(self.model.frame['member_id'].nunique(), 1728)
        self.assertTrue((self.model.frame['pdc'].between(0,1)).all())

    def test_root_tree_is_consistent(self):
        tree = self.model.tree([])
        self.assertEqual(tree['count'], self.count)
        self.assertEqual(sum(n['count'] for n in tree['children']), self.count)
        for market in tree['children']:
            self.assertEqual(sum(n['count'] for n in market['children']), market['count'])

    def test_drilldown_and_full_path(self):
        path = ['Tennessee', 'Operations North', 'Chattanooga']
        frame = self.model.scope(path)
        self.assertEqual(len(frame), 144)
        tree = self.model.tree(path, max_extra_depth=3)
        self.assertEqual(tree['count'], len(frame))
        self.assertEqual(tree['path'], path)
        self.assertEqual(self.model.validated_path(path+['not a group']), path)

    def test_pcp_jump(self):
        options = self.model.jump_options()
        self.assertTrue(options)
        path = json.loads(options[0]['value'])
        self.assertEqual(len(path), len(self.model.keys))
        self.assertGreater(len(self.model.scope(path)), 0)
        self.assertEqual(len(self.model.scope(path)), 9)

    def test_member_search_and_dot_cap(self):
        frame = self.model.members([], search='DEMO-000001')
        self.assertEqual(len(frame), 1)
        dots = self.model.member_dots([], limit=100)
        self.assertEqual(len(dots), 100)
        self.assertTrue(all('member_name' in d for d in dots))

    def test_optional_metrics_missing_not_fabricated(self):
        raw = pd.read_csv(self.csv).drop(columns=['RAF','PDC','Risk Score','Total Cost','Quality Gaps','ED Visits'])
        target = Path(self.tmp.name)/'no_metrics.csv'
        raw.to_csv(target,index=False)
        simplified = MembershipData(target)
        self.assertIsNone(simplified.stats(simplified.frame)['pdc'])
        self.assertEqual(simplified.risk_counts([])['Unknown'], len(raw))
        self.assertFalse(simplified.metric_available['cost'])

    def test_mapping(self):
        raw=pd.DataFrame({'MyMarket':['Test'], 'Dr':['Dr A'], 'Person':['P1']})
        target=Path(self.tmp.name)/'renamed.csv'
        raw.to_csv(target,index=False)
        mapping=Path(self.tmp.name)/'mapping.json'
        mapping.write_text(json.dumps({'operational_market':'MyMarket','pcp':'Dr','member_name':'Person'}))
        m=MembershipData(target,mapping)
        self.assertEqual(m.stats(m.frame)['count'],1)
        self.assertEqual(len(m.keys),2)

    def test_missing_member_id_fallback(self):
        raw=pd.DataFrame({'Operational Market':['Test','Test'], 'PCP':['Dr A','Dr A'],
                          'Member Name':['A','B'], 'PDC':['89%','73%']})
        target=Path(self.tmp.name)/'minimal.csv'
        raw.to_csv(target,index=False)
        m=MembershipData(target)
        self.assertEqual(len(set(m.frame.member_id)),2)
        self.assertAlmostEqual(m.stats(m.frame)['pdc'],.81)


if __name__ == '__main__':
    unittest.main()
