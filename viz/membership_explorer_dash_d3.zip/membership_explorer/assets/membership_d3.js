/* Native D3 hierarchy rendering for Dash. D3 v7 is loaded in app.py.
   Interactivity uses dash_clientside.set_props, not DOM input hacks. */
(function () {
  'use strict';
  let active = null;
  let observer = null;
  let resizeTimer = null;

  const colors = {
    ink: '#213b4a', accent: '#168e87', faint: '#e8f1f2',
    good: '#42b9a2', warn: '#d9af64', bad: '#d97665'
  };
  function number(v) { return v == null ? 'N/A' : Number(v).toLocaleString('en-US'); }
  function fmt(v, metric) {
    if (v === null || v === undefined || Number.isNaN(Number(v))) return 'N/A';
    if (metric === 'pdc') return (v * 100).toFixed(1) + '%';
    if (metric === 'cost') return '$' + Number(v).toLocaleString('en-US', {maximumFractionDigits:0});
    if (metric === 'gaps') return Number(v).toFixed(2);
    return Number(v).toFixed(2);
  }
  function fitName(name, max) {
    const value = String(name || '');
    return value.length <= max ? value : value.slice(0, Math.max(1, max-1)) + '…';
  }
  function setProps(id, props) {
    if (window.dash_clientside && typeof window.dash_clientside.set_props === 'function') {
      window.dash_clientside.set_props(id, props);
    }
  }
  function navigate(node, payload) {
    if (node.data.non_clickable) return;
    const path = node.data.path || [];
    if (JSON.stringify(path) === JSON.stringify(payload.path || [])) return;
    setProps('selection-store', {data: {path: path}});
    if (path.length >= payload.levels.length) setProps('view-control', {value: 'members'});
  }
  function colorFn(payload, metric, root) {
    if (!payload.available[metric]) return () => '#b4cbd2';
    const vals = root.descendants().filter(d => d.depth > 0 &&
      d.data[metric] !== undefined && d.data[metric] !== null).map(d => Number(d.data[metric]));
    if (!vals.length) return () => '#b4cbd2';
    const lo = metric === 'pdc' ? 0.55 : (metric === 'risk' ? 0 : Math.min(...vals));
    const hi = metric === 'pdc' ? 1 : (metric === 'risk' ? 1 : Math.max(...vals));
    const span = (hi - lo) || 1;
    return d => {
      const v = d.data[metric];
      if (v === null || v === undefined) return '#b4cbd2';
      const n = Math.max(0, Math.min(1, (Number(v) - lo) / span));
      if (metric === 'raf') return d3.interpolatePuBuGn(0.35 + n * .48);
      const beneficial = ['risk','cost','gaps'].includes(metric) ? 1-n : n;
      return d3.interpolateRdYlGn(.12 + beneficial * .77);
    };
  }
  function setup(stage, payload, metric) {
    d3.select(stage).selectAll('*').remove();
    const rect = stage.getBoundingClientRect();
    const width = Math.max(420, Math.floor(rect.width - 4));
    const tooltip = d3.select(stage).append('div').attr('class','d3-tooltip')
      .style('opacity',0).style('pointer-events','none');
    function showTip(event, d, isMember) {
      let el = tooltip;
      el.selectAll('*').remove();
      const node = d.data || d;
      el.append('strong').text(isMember ? node.member_name : node.name);
      const data = isMember ? [
        ['ID', node.member_id], ['Risk', node.risk_tier], ['RAF', fmt(node.raf,'raf')],
        ['PDC',fmt(node.pdc,'pdc')],['Cost',fmt(node.cost,'cost')],
        ['Quality gaps',node.gaps == null ? 'N/A' : node.gaps]
      ] : [
        ['Dimension',node.level], ['Members',number(node.count)], ['Avg PDC',fmt(node.pdc,'pdc')],
        ['Avg RAF',fmt(node.raf,'raf')], ['Avg risk',fmt(node.risk,'risk')],
        ['Cost / member',fmt(node.cost,'cost')], ['Gaps / member',fmt(node.gaps,'gaps')]
      ];
      data.forEach(pair => {
        let line = el.append('div').attr('class','tip-line');
        line.append('span').text(pair[0]);
        line.append('b').text(pair[1] == null ? 'N/A' : pair[1]);
      });
      tooltip.style('opacity',1);
      moveTip(event);
    }
    function moveTip(event) {
      const container = stage.getBoundingClientRect();
      const x = event.clientX - container.left;
      const y = event.clientY - container.top;
      const estimated = 260;
      tooltip.style('left', Math.min(Math.max(8,x+15),container.width-estimated-9)+'px')
        .style('top', Math.max(8,y-15)+'px');
    }
    function hideTip() { tooltip.style('opacity',0); }
    return {width, tooltip, showTip, moveTip, hideTip};
  }
  function initializeHierarchy(data) {
    const root = d3.hierarchy(data);
    root.sum(d => d.children && d.children.length ? 0 : (d.count || 0));
    root.sort((a,b) => b.value-a.value || a.data.name.localeCompare(b.data.name));
    return root;
  }
  function hint(stage, headline, body) {
    const node = d3.select(stage).append('div').attr('class','empty-state');
    node.append('div').attr('class','empty-glyph').text('◎');
    node.append('h3').text(headline);
    node.append('p').text(body);
  }
  function sunburst(stage, payload, metric) {
    const s = setup(stage, payload, metric), root = initializeHierarchy(payload.tree);
    if (!root.children || !root.children.length) {
      hint(stage, 'This branch has no visible children', 'Choose Members to see individual records.');
      return;
    }
    const h = 505;
    const radius = Math.min(s.width,h) * .47;
    const inner = radius * .20;
    const ring = (radius-inner) / Math.max(1,root.height);
    d3.partition().size([Math.PI * 2, root.height + 1])(root);
    const scale = colorFn(payload, metric, root);
    const svg = d3.select(stage).append('svg').attr('viewBox',`0 0 ${s.width} ${h}`)
      .attr('role','img').attr('aria-label','Interactive sunburst membership hierarchy');
    const g = svg.append('g').attr('transform',`translate(${s.width/2},${h/2})`);
    const arc = d3.arc().startAngle(d=>d.x0).endAngle(d=>d.x1).padAngle(.004)
      .padRadius(radius).innerRadius(d=>inner+(d.depth-1)*ring+2)
      .outerRadius(d=>inner+d.depth*ring-2);
    const nodes = root.descendants().filter(d=>d.depth>0);
    const piece = g.selectAll('path.slice').data(nodes).join('path')
      .attr('class', d => d.data.non_clickable ? 'slice not-clickable' : 'slice')
      .attr('d',arc).attr('fill',d=>scale(d))
      .on('mousemove',(e,d)=>{s.showTip(e,d);})
      .on('mouseleave',s.hideTip).on('click',(e,d)=>navigate(d,payload));
    piece.append('title').text(d=>`${d.data.name}: ${number(d.data.count)} members`);
    g.selectAll('text.arc-label').data(nodes.filter(d=>(d.x1-d.x0)*(inner+(d.depth-.5)*ring)>58))
      .join('text').attr('class','arc-label').attr('pointer-events','none')
      .attr('transform',d=>{
        const angle = ((d.x0+d.x1)/2)*180/Math.PI-90;
        const r = inner+(d.depth-.5)*ring;
        const flip = angle > 90 && angle < 270 ? 180 : 0;
        return `rotate(${angle}) translate(${r},0) rotate(${flip})`;
      }).attr('text-anchor','middle')
      .text(d=>fitName(d.data.name, Math.max(6, Math.floor((d.x1-d.x0)*(inner+(d.depth-.5)*ring)/8))));
    g.append('circle').attr('r',inner-8).attr('fill','#fff').attr('stroke','#e6eeef');
    g.append('text').attr('class','sun-center-caption').attr('text-anchor','middle').attr('y',-12)
      .text('CURRENT SCOPE');
    g.append('text').attr('class','sun-center-number').attr('text-anchor','middle').attr('y',14)
      .text(number(payload.count));
    g.append('text').attr('class','sun-center-caption').attr('text-anchor','middle').attr('y',33)
      .text('MEMBERS');
  }
  function icicle(stage, payload, metric) {
    const s = setup(stage,payload,metric), root=initializeHierarchy(payload.tree);
    if (!root.children || !root.children.length) {
      hint(stage,'You reached the PCP level','Open Members to inspect this PCP’s member records.');
      return;
    }
    const h = 485;
    d3.partition().size([s.width-32,h-36]).padding(1.7)(root);
    const color = colorFn(payload,metric,root);
    const svg=d3.select(stage).append('svg').attr('viewBox',`0 0 ${s.width} ${h}`)
      .attr('role','img').attr('aria-label','Interactive icicle membership hierarchy');
    const g=svg.append('g').attr('transform','translate(16,12)');
    const nodes=root.descendants();
    const cells=g.selectAll('g.icicle-node').data(nodes).join('g').attr('class','icicle-node');
    cells.append('rect').attr('x',d=>d.x0).attr('y',d=>d.y0)
      .attr('rx',4).attr('width',d=>Math.max(0,d.x1-d.x0))
      .attr('height',d=>Math.max(0,d.y1-d.y0))
      .attr('fill',d=>d.depth===0?'#203d4b':color(d))
      .attr('opacity',d=>d.data.non_clickable?0.5:1)
      .style('cursor',d=>d.depth===0||d.data.non_clickable?'default':'pointer')
      .on('mousemove',(e,d)=>s.showTip(e,d)).on('mouseleave',s.hideTip)
      .on('click',(e,d)=>navigate(d,payload));
    cells.filter(d=>(d.x1-d.x0)>85).append('text').attr('x',d=>d.x0+10)
      .attr('y',d=>(d.y0+d.y1)/2-5).attr('class',d=>d.depth===0?'icicle-label icicle-root':'icicle-label')
      .text(d=>fitName(d.data.name,Math.max(4,Math.floor((d.x1-d.x0-20)/7.3))));
    cells.filter(d=>(d.x1-d.x0)>96).append('text').attr('x',d=>d.x0+10)
      .attr('y',d=>(d.y0+d.y1)/2+16).attr('class',d=>d.depth===0?'icicle-count icicle-root':'icicle-count')
      .text(d=>number(d.data.count)+' members');
    nodes.filter(d=>d.depth>0&&d.x1-d.x0>24).forEach(d=>{
      g.append('rect').attr('x',d.x0).attr('y',d.y0)
        .attr('width',d.x1-d.x0).attr('height',d.y1-d.y0)
        .attr('fill','transparent').style('cursor',d.data.non_clickable?'default':'pointer')
        .on('mousemove',(e)=>s.showTip(e,d)).on('mouseleave',s.hideTip)
        .on('click',()=>navigate(d,payload));
    });
  }
  function treemap(stage, payload, metric) {
    const s=setup(stage,payload,metric),root=initializeHierarchy(payload.tree);
    if (!root.children || !root.children.length) {
      hint(stage,'No subgroups to draw','Select Members to explore this population.');
      return;
    }
    const h=485;
    d3.treemap().size([s.width-28,h-24]).paddingInner(3).paddingTop(d=>d.depth===0?0:21)
      .paddingOuter(2).round(true)(root);
    const color=colorFn(payload,metric,root);
    const svg=d3.select(stage).append('svg').attr('viewBox',`0 0 ${s.width} ${h}`)
      .attr('role','img').attr('aria-label','Interactive treemap membership distribution');
    const g=svg.append('g').attr('transform','translate(14,12)');
    const descendants=root.descendants().filter(d=>d.depth>0);
    descendants.sort((a,b)=>a.depth-b.depth);
    const cells=g.selectAll('g.tree-cell').data(descendants).join('g').attr('class','tree-cell');
    cells.append('rect').attr('x',d=>d.x0).attr('y',d=>d.y0)
      .attr('width',d=>Math.max(0,d.x1-d.x0)).attr('height',d=>Math.max(0,d.y1-d.y0))
      .attr('rx',4).attr('fill',d=>d.children?'#ecf3f4':color(d))
      .attr('stroke',d=>d.children?'#d8e7e9':'#fff')
      .attr('stroke-width',d=>d.children?1.5:1)
      .on('mousemove',(e,d)=>s.showTip(e,d)).on('mouseleave',s.hideTip)
      .on('click',(e,d)=>navigate(d,payload));
    cells.filter(d=>d.children && d.x1-d.x0>68 && d.y1-d.y0>45)
      .append('text').attr('class','tree-parent-label').attr('x',d=>d.x0+8)
      .attr('y',d=>d.y0+15).text(d=>fitName(d.data.name,Math.floor((d.x1-d.x0)/7)));
    cells.filter(d=>!d.children && d.x1-d.x0>54 && d.y1-d.y0>30)
      .append('text').attr('class','tree-leaf-label').attr('x',d=>d.x0+8)
      .attr('y',d=>d.y0+17)
      .text(d=>fitName(d.data.name,Math.floor((d.x1-d.x0-12)/7)));
    cells.filter(d=>!d.children && d.x1-d.x0>58 && d.y1-d.y0>52)
      .append('text').attr('class','tree-leaf-count').attr('x',d=>d.x0+8)
      .attr('y',d=>d.y0+34).text(d=>number(d.data.count)+' members');
  }
  function memberDots(stage,payload,metric) {
    const s=setup(stage,payload,metric),members=payload.members||[];
    if (!members.length) {
      hint(stage,'No matching member records','Change your member search or choose a different group.');
      return;
    }
    const grouping=['High','Moderate','Low','Unknown'];
    const fillMap={'High':'#fcebe7','Moderate':'#fff4df','Low':'#e5f7f3','Unknown':'#f0f3f6'};
    const tierColor={'High':'#cf7664','Moderate':'#be9354','Low':'#199c85','Unknown':'#8296a4'};
    const cols=Math.max(12,Math.floor((s.width-240)/19));
    const rows=grouping.map(name=>({name,items:members.filter(d=>d.risk_tier===name)}))
      .filter(x=>x.items.length);
    const spacing=19;
    const totalHeight=rows.reduce((n,g)=>n+Math.max(78,Math.ceil(g.items.length/cols)*spacing+48),20)+20;
    const svg=d3.select(stage).append('svg')
      .attr('viewBox',`0 0 ${s.width} ${totalHeight}`).attr('role','img')
      .attr('aria-label','Interactive grouped membership dot map');
    const numeric=members.filter(d=>d[metric]!==null && d[metric]!==undefined).map(d=>Number(d[metric]));
    const min=numeric.length?Math.min(...numeric):0;
    const max=numeric.length?Math.max(...numeric):1;
    function dotFill(d){
      if(!payload.available[metric]||d[metric]==null) return '#93abb7';
      let val=metric==='pdc'?Math.max(0,Math.min(1,(d[metric]-.5)/.5)):
        (metric==='risk'?Math.max(0,Math.min(1,Number(d[metric]))):
         Math.max(0,Math.min(1,(Number(d[metric])-min)/(max-min||1))));
      if(metric==='raf')return d3.interpolatePuBuGn(.35+val*.48);
      if(['risk','cost','gaps'].includes(metric))val=1-val;
      return d3.interpolateRdYlGn(.12+val*.77);
    }
    let top=14;
    rows.forEach(tier=>{
      const numRows=Math.ceil(tier.items.length/cols);
      const height=Math.max(78,numRows*spacing+48);
      svg.append('rect').attr('x',8).attr('y',top).attr('width',s.width-16)
        .attr('height',height-8).attr('rx',10).attr('fill',fillMap[tier.name]);
      svg.append('rect').attr('x',24).attr('y',top+17).attr('width',6)
        .attr('height',19).attr('rx',3).attr('fill',tierColor[tier.name]);
      svg.append('text').attr('x',38).attr('y',top+31).attr('class','tier-label')
        .text(tier.name+' risk');
      svg.append('text').attr('x',160).attr('y',top+31).attr('class','tier-count')
        .text(number(tier.items.length)+' members');
      svg.selectAll(null).data(tier.items).enter().append('circle')
        .attr('cx',(d,i)=>202+(i%cols)*spacing).attr('cy',(d,i)=>top+34+Math.floor(i/cols)*spacing)
        .attr('r',d=> d.cost!=null ? Math.max(4.5,Math.min(8,4.5+Math.sqrt(Math.max(0,d.cost))/37)):6)
        .attr('fill',dotFill).attr('stroke','#fff').attr('stroke-width',1.2)
        .attr('class','member-dot')
        .on('mousemove',(e,d)=>s.showTip(e,d,true)).on('mouseleave',s.hideTip)
        .on('click',(e,d)=>setProps('member-search',{value:d.member_id}));
      top+=height;
    });
    if (payload.has_more_members) {
      d3.select(stage).append('div').attr('class','dot-note')
        .text('Showing first '+number(members.length)+' matching members. Use search or the paginated table to explore more.');
    }
  }
  function draw(payload,view,metric) {
    const stage=document.getElementById('d3-hierarchy');
    if (!stage) return 'Visualization mount not found.';
    if (typeof window.d3==='undefined'){
      d3Missing(stage);
      return 'D3 could not load. Connect to the internet or save d3.min.js into assets/.';
    }
    active={payload,view,metric};
    if (!observer && typeof ResizeObserver !== 'undefined') {
      observer=new ResizeObserver(()=>{
        if(!active)return;
        clearTimeout(resizeTimer);
        resizeTimer=setTimeout(()=>draw(active.payload,active.view,active.metric),130);
      });
      observer.observe(stage);
    }
    if(view==='sunburst') sunburst(stage,payload,metric);
    else if(view==='treemap')treemap(stage,payload,metric);
    else if(view==='members')memberDots(stage,payload,metric);
    else icicle(stage,payload,metric);
    return '';
  }
  function d3Missing(stage) {
    stage.textContent='D3 could not load. You need internet access for the D3 CDN, or save d3.min.js in assets/ and remove external_scripts from app.py.';
  }
  window.membershipD3={draw};
})();
